package Asia_Pacific_Airport;

import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Phaser;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.TimeUnit;

public class Plane implements Runnable {

    private final int number;
    private final long arrivalTime;
    private final String callSign;
    public final String aircraftModelCode;
    public final AtomicInteger planesServed = new AtomicInteger(0);
    private final Passenger passenger;
    private boolean emergency;
    private final Random random = new Random();
    private final RefuelTruck refuelTruck;


    public Plane(int number, String aircraftModelCode, RefuelTruck refuelTruck) {
        this.number = number;
        this.arrivalTime = System.currentTimeMillis();
        this.aircraftModelCode = aircraftModelCode;
        this.callSign = "Plane " + number + " CODE: " + generateRandomLetters() + " " + generateRandomNumber() + " TYPE: " + aircraftModelCode;
        this.passenger = new Passenger(callSign);
        this.emergency = random.nextBoolean() && random.nextBoolean(); 
        this.refuelTruck = refuelTruck;


        AirportSimulation.planesEmbarked[number - 1] = new AtomicInteger(0); 
        AirportSimulation.planesDisembarked[number - 1] = new AtomicInteger(0); 
    }

    @Override
    public void run() {
        try {
            ATC atc = new ATC();
            atc.requestLandingPermission(this);
            atc.requestLanding(this);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public void landAndProcess() throws InterruptedException {
        System.out.println("ATC Administrator: " + callSign + " is approved to land");
        Thread.sleep(200);
        System.out.println("Pilot: " + callSign + " is landing.");
        Thread.sleep(1000); 

        ATC atc = new ATC();
        atc.addPlaneToGround(this);
        atc.gates.acquire();
        processAtGate();
        atc.gates.release();
        atc.removePlaneFromGround(this);
        
        System.out.println("Pilot: " + callSign + " is ready to take off.");
        Thread.sleep(1000);
        System.out.println("ATC Administrator: " + callSign + " good bye.");
        Thread.sleep(500);
        System.out.println("Pilot: " + callSign + " is taking off.");
        Thread.sleep(1000); 
    }

    private void processAtGate() throws InterruptedException {
        System.out.println("Pilot: " + callSign + " is at the gate.");
        ExecutorService gateService = Executors.newFixedThreadPool(5);

        Phaser phaser = new Phaser(1); 

        gateService.submit(() -> {
            try {
                System.out.println("Pilot: " + callSign + " is disembarking passengers.");
                int disembarkedPassengers = random.nextInt(AirportSimulation.MAX_PASSENGERS + 1);
                passenger.disembarkPassengers(disembarkedPassengers);
                AirportSimulation.planesDisembarked[number - 1].getAndAdd(disembarkedPassengers);
                Thread.sleep(500); 
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                phaser.arriveAndDeregister();
            }
        });

        phaser.register(); 

        phaser.arriveAndAwaitAdvance();

        gateService.submit(() -> {
            try {
                System.out.println("Pilot: " + callSign + " is embarking passengers.");
                int embarkedPassengers = random.nextInt(AirportSimulation.MAX_PASSENGERS + 1);
                passenger.embarkPassengers(embarkedPassengers);
                AirportSimulation.planesEmbarked[number - 1].getAndAdd(embarkedPassengers);
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });

        gateService.submit(() -> {
            try {
                System.out.println("Cleaning Team: " + callSign + " is being cleaned.");
                Thread.sleep(1000); 
                System.out.println("Cleaning Team: " + callSign + " cleaning completed.");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });


        gateService.submit(() -> {
            try {
                refuelTruck.refuelPlane(callSign);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });

        gateService.shutdown();
        gateService.awaitTermination(1, TimeUnit.MINUTES);
    }

    public boolean isEmergency() {
        return emergency;
    }

    public long getArrivalTime() {
        return arrivalTime;
    }

    public int getNum() {
        return number;
    }

    public String getCallSign() {
        return callSign;
    }

    private String generateRandomLetters() {
        char[] letters = new char[3];
        for (int i = 0; i < 3; i++) {
            letters[i] = (char) ('A' + random.nextInt(26));
        }
        return new String(letters);
    }

    private int generateRandomNumber() {
        return random.nextInt(900) + 100; 
    }
}
