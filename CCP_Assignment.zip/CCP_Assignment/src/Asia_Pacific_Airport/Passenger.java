package Asia_Pacific_Airport;


public class Passenger {

        private final String callSign;

        public Passenger(String callSign) {
            this.callSign = callSign;
        }

        public void embarkPassengers(int count) throws InterruptedException {
            for (int i = 1; i <= count; i++) {
                System.out.println("Gate : " + callSign + " Passenger " + i + " is embarking.");
                Thread.sleep(100); 
            }
        }

        public void disembarkPassengers(int count) throws InterruptedException {
            for (int i = 1; i <= count; i++) {
                System.out.println("Gate : " + callSign + " Passenger " + i + " is disembarking.");
                Thread.sleep(100); 
            }
        }
    }
