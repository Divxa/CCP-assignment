package Asia_Pacific_Airport;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class AirportSimulation {

    private final ATC atc = new ATC();
    public static final int MAX_PLANES_ON_GROUND = 3;
    public static final int MAX_GATES = 3; 
    public static final int MAX_PASSENGERS = 50; 
    public static final int TOTAL_PLANES = 6; 

    private final Random random = new Random();
    public static final List<Long> waitingTimes = Collections.synchronizedList(new ArrayList<>()); 
    public static final AtomicInteger[] planesEmbarked = new AtomicInteger[TOTAL_PLANES];   
    public static final AtomicInteger[] planesDisembarked = new AtomicInteger[TOTAL_PLANES];
    public static final RefuelTruck refuelTruck = new RefuelTruck();

    public static void main(String[] args) throws InterruptedException { 
        new AirportSimulation().simulate(); 
    }

    public void simulate() throws InterruptedException {
        System.out.println("ATC Administrator: In position, ready to work");
        System.out.println("Refuel Truck: In position, ready to work");
        System.out.println("Resupplies Truck : In position, ready to work");
        System.out.println("Cleaning Team: In position, ready to work");
        System.out.println("ATC Administrator: Welcome to Asia Pacific Airport !");
        ExecutorService executor = Executors.newCachedThreadPool();

        for (int i = 0; i < TOTAL_PLANES; i++) {
            int id = i + 1;
            executor.submit(() -> {  
                try {
                    Plane plane = new Plane(id, getAircraftModelCode(), refuelTruck); 
                    atc.requestLandingPermission(plane);
                    atc.requestLanding(plane);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt(); 
                }
            });

            Thread.sleep(random.nextInt(2000)); 
        }

        executor.shutdown();   
        executor.awaitTermination(1, TimeUnit.MINUTES);

        
        printStatistics();
    }

    private void printStatistics() {
        System.out.println("ATC Administrator: Operation done, time to undergo checking");
        System.out.println("Checking in progress: ");
        System.out.println("Gates should be empty: " + (atc.gates.availablePermits() == MAX_GATES));

        System.out.println("\nStatistics:");

        for (int i = 0; i < TOTAL_PLANES; i++) {
            String callSign = "Plane " + (i + 1) + "  " ;
            int embarked = planesEmbarked[i].get();
            int disembarked = planesDisembarked[i].get();
            System.out.println(callSign + ": Passengers boarded = " + embarked + ", Passengers disembarked = " + disembarked);
        }

        int totalPassengersBoarded = 0;
        for (AtomicInteger embarked : planesEmbarked) {
           totalPassengersBoarded += embarked.get();
        }

        int totalPassengersDisembarked = 0;
        for (AtomicInteger disembarked : planesDisembarked) {
         totalPassengersDisembarked += disembarked.get();
        }

        System.out.println("\nOverall Statistics:");
        System.out.println("Total planes served: " + TOTAL_PLANES);
        System.out.println("Total passengers boarded: " + totalPassengersBoarded);
        System.out.println("Total passengers disembarked: " + totalPassengersDisembarked);

        if (!waitingTimes.isEmpty()) {
            long maxWait = Collections.max(waitingTimes);
            long minWait = Collections.min(waitingTimes);
            
            double avregeWait = 0.0;
           if (!waitingTimes.isEmpty()) {
                 long sumWait = 0;
            for (Long wait : waitingTimes) {
                 sumWait += wait;
              }
              avregeWait = (double) sumWait / waitingTimes.size();
            }

            System.out.println("\nWaiting Time Statistics:");
            System.out.println("Maximum waiting time: " + maxWait + " ms");
            System.out.println("Minimum waiting time: " + minWait + " ms");
            System.out.println("Average waiting time: " +  (int) avregeWait + " ms");
        }

        atc.printGateStatus(); 
    }

    private String getAircraftModelCode() {
        String[] aircraftModels = {"Boeing 747", "Airbus A380", "Airbus A350", "Boeing 787"};
        return aircraftModels[random.nextInt(aircraftModels.length)];
    }
}