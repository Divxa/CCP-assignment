/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Asia_Pacific_Airport;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Semaphore;  

public class ATC {

    private final Semaphore runway = new Semaphore(1);  
    final Semaphore gates = new Semaphore(AirportSimulation.MAX_GATES);   
    private final Semaphore planesOnGround = new Semaphore(AirportSimulation.MAX_PLANES_ON_GROUND); 
    private final List<Plane> planesOnGroundList = Collections.synchronizedList(new ArrayList<>()); 
                                                                                                        
    public void requestLandingPermission(Plane plane) throws InterruptedException {       
        System.out.println("Pilot :  " + plane.getCallSign() + " is requesting landing permission."); 
        if (plane.isEmergency()) {
            System.out.println("Pilot :  " + plane.getCallSign() + " has emergency priority!");
            runway.acquire(); 
        } else {
             //still need consideration
        }
    }

    public void requestLanding(Plane plane) throws InterruptedException {  
        long startTime = System.currentTimeMillis();
        System.out.println("Pilot :  " + plane.getCallSign() + " is waiting for landing.");

        planesOnGround.acquire();  
        planesOnGroundList.add(plane); 

        while (gates.availablePermits() == 0) {
            System.out.println("No available gates for " + plane.getCallSign() + " to land. Looking for available gate to land.");
            Thread.sleep(1000); 
        }
    
        plane.landAndProcess();   
        planesOnGround.release();
        planesOnGroundList.remove(plane);

        long endTime = System.currentTimeMillis(); 
        long waitingTime = endTime - startTime;
        AirportSimulation.waitingTimes.add(waitingTime);  
    }

    public void printGateStatus() {           
        int availableGates = gates.availablePermits(); 
        System.out.println("\nGate Status:");
        for (int i = 0; i < AirportSimulation.MAX_GATES; i++) {
            if (i < (AirportSimulation.MAX_GATES - availableGates)) {
                System.out.println("Gate : " + (i + 1) + ": Occupied");
            } else {
                System.out.println("Gate : " + (i + 1) + ": Available");
            }
        }
    }

    public synchronized void addPlaneToGround(Plane plane) { 
        planesOnGroundList.add(plane);                  
    }

    public synchronized void removePlaneFromGround(Plane plane) {   
        planesOnGroundList.remove(plane);  
    }
}