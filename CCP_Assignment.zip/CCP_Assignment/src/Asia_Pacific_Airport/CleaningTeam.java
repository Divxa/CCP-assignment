/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Asia_Pacific_Airport;

 public class CleaningTeam {
    
    public void cleanPlane(String callSign) throws InterruptedException {
        System.out.println("Cleaning Team: " + callSign + " is being cleaned.");
        Thread.sleep(1000); 
        System.out.println("Cleaning Team: " + callSign + " cleaning completed.");
        Thread.sleep(100); 
     }
 
  }
 



