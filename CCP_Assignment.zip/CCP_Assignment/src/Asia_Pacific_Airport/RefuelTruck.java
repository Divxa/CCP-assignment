package Asia_Pacific_Airport;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class RefuelTruck {

    private final Lock lock = new ReentrantLock(); 

    public synchronized void refuelPlane(String callsign) throws InterruptedException {  
        lock.lock();                                      
        try {
            int percentage = 0;
            while (percentage < 100) {
                percentage += 10;
                System.out.println("Refuel and supply Truck : " + callsign + " is refueling & resupply " + percentage + "%");
                Thread.sleep(500);   
            }
        } finally {
            System.out.println("Refuel and supply Truck: Gaining oil for next plane to refill and resupply");
              Thread.sleep(150);
            lock.unlock();
        }
    }
}